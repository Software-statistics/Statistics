import data


# category like:'Shoes>Boys>Outdoor' 
def recommendcommodity(category):
	return asin
	
def recommendprice(asin):
	return price
