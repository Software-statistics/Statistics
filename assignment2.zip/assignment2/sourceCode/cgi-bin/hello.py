#!/usr/local/bin/python2.7

import cgi
import cgitb
cgitb.enable()

print ("HTTP/1.0 200 OK")
print ("Content-Type: text/html")
print ("")
print ("") 
print ("<p>hello</p>")