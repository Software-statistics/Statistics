#-*- coding:utf-8 -*-

from star_count import starcount
from star_count import starcount0
from star_count import starcountall

if __name__ == '__main__':
        # Shoes>Boys>Outdoor
	#starcount('Shoes>Boys>Outdoor', 12)
        # B003YUC4YI
        #starcount0('B003YUC4YI')

        starcountall('Shoes>Boys>Outdoor')
